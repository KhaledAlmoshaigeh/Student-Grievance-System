<?php
include 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'connection.php'; // Connection script

$action = $_POST['action'];

if ($action == 'fetch') {
    $complaintId = $_POST['complaintId'];
    $response = array();

    if ($stmt = mysqli_prepare($conn, "SELECT email, status, dept FROM $complaint WHERE number = ?")) {
        mysqli_stmt_bind_param($stmt, "i", $complaintId);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $email, $status, $dept);
        mysqli_stmt_fetch($stmt);
        $response = array('email' => $email, 'status' => $status, 'dept' => $dept);
        mysqli_stmt_close($stmt);
    }
    
    echo json_encode($response);
} elseif ($action == 'update') {
    $complaintId = $_POST['complaintId'];
    $status = $_POST['status'];
    $dept = $_POST['dept'];
    $email = $_POST['email'];
    
    if ($dept == "None" || empty($dept)) {

        $query = "UPDATE $complaint SET status=? WHERE number=?";
        if ($stmt = mysqli_prepare($conn, $query)) {
            mysqli_stmt_bind_param($stmt, "si", $status, $complaintId);
            
        }
    } else {
        // Update both status and department
        $query = "UPDATE $complaint SET status=?, dept=? WHERE number=?";
        if ($stmt = mysqli_prepare($conn, $query)) {
            mysqli_stmt_bind_param($stmt, "ssi", $status, $dept, $complaintId);
        }
    }

    mysqli_stmt_execute($stmt);
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        try{

            $mail = new PHPMailer(true);
            // Server settings for PHPMailer
            $mail->isSMTP();                                     
            $mail->Host = 'smtp.gmail.com';                         
            $mail->SMTPAuth = true;                               
            $mail->Username = $sgsEmail;
            $mail->Password = $emailPassword;              
            $mail->SMTPSecure = 'tls';                            
            $mail->Port = 587;      

            $mail->setFrom($sgsEmail, 'Student Grievance System');
            $mail->addAddress($email , "dear student");
            $mail->addReplyTo($sgsEmail, 'Student Grievance System');

            $mail->isHTML(true);
            $mail->Subject = 'Complaint Status Update';
            $mail->Body = 'Dear User, Your complaint status has been updated to: ' . $status;
            $mail->send();}
        

            catch(Exception $e) {
                echo 'Message: ' .$e->getMessage();
              }
    } else {
        echo "No changes were made to update.";
    }
    mysqli_stmt_close($stmt);
}

mysqli_close($conn);
?>
