$(document).ready(function () {
  $('#create-account-form').submit(function (event) {
      event.preventDefault();  // Prevent the traditional form submission

      var formData = new FormData(this);

      $.ajax({
          type: 'POST',
          url: 'Create-account-be.php',
          data: formData,
            processData: false,  // Important: don't let jQuery process the data
            contentType: false,  // Important: don't specify a content-type
            success: function (response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Account Created successfully!',

                    showConfirmButton: true
                });
            },
            error: function (xhr, status, error) {
                Swal.fire({
                    icon: 'error',
                    title: 'account creation failed!',
                    text: response,
                    showConfirmButton: true
                });
            }
        });
    });
});