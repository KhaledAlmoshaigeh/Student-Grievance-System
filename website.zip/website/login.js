$(document).ready(function () {
    $('#login-form').submit(function (event) {
        event.preventDefault();
        var username = $('input[name="username"]').val();
        var password = $('input[name="Password"]').val();

        $.ajax({
            type: 'POST',
            url: 'login-be.php',
            data: {
                username: username,
                Password: password
            },
            success: function (response) {
                if (response.trim() === 'student') {
                    window.location.href = 'student.php';
                } else if (response.trim() === 'sgs') {
                    window.location.href = 'sgs.php';
                } else {
                    alert(response);
                    window.location.href = 'login.php';
                }
            },
            error: function () {
                alert('An error occurred. Please try again.');
            }
        });
    });
});