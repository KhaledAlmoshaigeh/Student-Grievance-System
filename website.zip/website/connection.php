<?php
$conn = mysqli_connect("localhost", "root" , "" , "SGS");


//php mailler email and password (smtp.gmail)
$sgsEmail = "";
$emailPassword = "";

//database tables
$account = "Account"; //this is where we store the accounts after they signed up
$complaint = "complaint"; // this is where we store complaints
?>