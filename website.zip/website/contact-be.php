<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include 'connection.php'; 
include 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


session_start();
$mail = new PHPMailer(true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_SESSION['username'];


    // Initialize variables from POST data
    $title = $_POST['title'];
    $email = $_POST['Email'];
    $message = $_POST['message'];
try{
    $mail->isSMTP();                                     
    $mail->Host = 'smtp.gmail.com';                         
    $mail->SMTPAuth = true;                               
    $mail->Username = $sgsEmail;
    $mail->Password = $emailPassword;              
    $mail->SMTPSecure = 'tls';                            
    $mail->Port = 587;                                    

    // Recipients
    $mail->setFrom($sgsEmail, 'Student Grievance System');
    $mail->addAddress($email, "Dear Student");
    $mail->addReplyTo($sgsEmail, 'Student Grievance System');

    // Content
    $mail->isHTML(true);
    $mail->Subject = $title;
    $mail->Body = "$message from $username";

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";

}
}
else{
    echo "post did not connect";
}