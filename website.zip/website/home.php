<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="navs.css" rel="stylesheet">
    <link href="home.css" rel="stylesheet">
</head>
<body bgcolor="#0a9396">
    <nav class="navbar navbar-custom navbar-expand-lg" >
        <div class="container-fluid">
          <a class="navbar-brand" href="home.php"><h1 class="navtitle">Student Grievance System</h1></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="home.php">Home</a>
              </li>
             
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">About Us</a>
              </li>
              <!-- add more tabes here --></ul> 
              <a href="Create-Account.php"><button type="button" class="btn btn-outline-success CA">Create Account</button></a> 
              <a href="login.php"><button type="button" class="btn btn-outline-info login">login</button></a>
            </div> </div> </nav>

            <div class="banner">
              <br>
                <div class="container text-center" id="myDivm">
                    <div class="row">
                      <div class="col-sm-6">
                        <br>
                        <h1><b>Student Grievance Hub</b></h1>
                        <p> Empowering Change through a Supportive Grievance System </p>
                      </div>
                      <div class="col-sm-6">
                        <img src="happy customer.v1.v1.png" class="img-fluid">
                      </div>
                     
                    </div>
                  </div>
            </div>
<br>
          <div class="mustaqbal container" id="myDiv"> <div class="row">
          <div class="col-sm-6"><p class="speach lead"><b>At Mustaqbal Universtiy</b><br>
           we believe in the power of student feedback.
            Our Student Grievance System provides a safe and confidential space for you to express your concerns, allowing us to address them promptly and effectively. Whether you encounter challenges related to academics, 
            campus facilities, or interpersonal matters, we are here to listen and take action.</p> </div> 
          <div class="col-sm-6"><img src="mostaqbal_prev_ui.png" class="imagee img-fluid"> </div> 
        
        </div> </div>

        <br>
          <div class="mustaqbal2 container" id="myDiv1"> <div class="row">
          <div class="col-sm-6">             <br>
<img src="customerservice.webp " class="ima img-fluid"></div> 
          <div class="col-sm-6"><p class="speach lead"> Our Student Grievance Hub is a testament to our <br>commitment  to student welfare and academic excellence. It serves <br>as a central resource where students can confidentially report grievances, ranging from academic matters to campus-related issues. We are dedicated to addressing these concerns promptly and fairly, striving to find effective solutions that promote student success and well-being.

By embracing an open and transparent approach, we empower students to actively participate in shaping their university experience. Our Student Grievance Hub fosters dialogue, encourages collaboration, and strengthens the relationship between students and the university administration. Together, we can build a campus community that thrives on mutual respect, understanding, and continuous improvement</p></div> 
        
        </div> </div>

        <br> <br>
        <nav class="navbar fixed-bottom navbar-dark bg-primary">
  <a class="navbar-brand" href="#">Mustaqbal Universtiy</a>
  <a class="nav-link active" href="https://www.linkedin.com/in/khaled-almoshaigeh-787912291/"><img src="images (1).png" class="imgg"></a>

</nav>
<script src="homes.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>  
</body>
</html>