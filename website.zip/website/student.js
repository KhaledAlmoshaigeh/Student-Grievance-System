$(document).ready(function () {
    $('#student').submit(function (event) {
        event.preventDefault(); // Prevent the typical form submission

        var formData = new FormData(this);  // Use the form element to initialize FormData

        $.ajax({
            type: 'POST',
            url: 'student-be.php',
            data: formData,
            processData: false,  // Important: don't let jQuery process the data
            contentType: false,  // Important: don't specify a content-type
            success: function (response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Submitted successfully!',
                  // Show server response
                    showConfirmButton: true
                });
            },
            error: function (xhr, status, error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Submission failed!',
                    text: 'An error occurred. Please try again later.',
                    showConfirmButton: true
                });
            }
        });
    });
});
