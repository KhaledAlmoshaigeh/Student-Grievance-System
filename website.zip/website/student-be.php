<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include 'connection.php';
include 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


session_start();
$mail = new PHPMailer(true);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_SESSION['username'];


    // Initialize variables from POST data
    $title = $_POST['title'];
    $email = $_POST['Email'];
    $dept = $_POST['dept'];
    $message = $_POST['message'];
   


function email($email ,$username){
    include 'connection.php';

    try {
        $mail = new PHPMailer(true);
        // Server settings for PHPMailer
        $mail->isSMTP();                                     
        $mail->Host = 'smtp.gmail.com';                         
        $mail->SMTPAuth = true;                               
        $mail->Username = $sgsEmail;
        $mail->Password = $emailPassword;              
        $mail->SMTPSecure = 'tls';                            
        $mail->Port = 587;                                    

        // Recipients
        $mail->setFrom($sgsEmail, 'Student Grievance System');
        $mail->addAddress($email, $username);
        $mail->addReplyTo($sgsEmail, 'Student Grievance System');

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'We received your complaint!';
        $mail->Body = "Thank you, $username. We will update you in 48 hours.";

        $mail->send();
        echo 'Message has been sent';
        echo "New complaint and email sent successfully.";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}


    $query="INSERT INTO $complaint (username, title, email, dept, message) Values(? ,? ,? ,? ,? )";
    $stmt=$conn->prepare($query);
    $stmt->bind_param("sssss", $username , $title ,$email , $dept ,$message);
    if($stmt->execute()){
        email($email ,$username);
        echo"we have recived your complaint";
    }




      
       
}

$conn->close();
?>
