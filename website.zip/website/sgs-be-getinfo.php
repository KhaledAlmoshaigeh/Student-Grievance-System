<?php
session_start();
require 'connection.php'; // Ensure your database connection script is included

// Check the connection
if (!$conn) {
    error_log("Connection failed: " . mysqli_connect_error());
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['complaint_id'])) {
    $complaint_id = $_POST['complaint_id'];
    error_log("Received complaint ID: " . $complaint_id); // Debug log

    // Query to get the user information based on complaint ID
    $sql = "SELECT username FROM complaint WHERE number = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $complaint_id);

        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $complaint = $result->fetch_assoc();
                $username = $complaint['username'];

                // Query to get user info by username
                $user_sql = "SELECT * FROM $account WHERE username = ?";
                $user_stmt = $conn->prepare($user_sql);
                $user_stmt->bind_param("s", $username);

                if ($user_stmt->execute()) {
                    $user_result = $user_stmt->get_result();
                    if ($user_result->num_rows > 0) {
                        // Output the information
                        while ($row = $user_result->fetch_assoc()) {
                            echo "Username: " . $row['username'] . "<br>";
                            echo "Email: " . $row['Email'] . "<br>";
                            echo "Student Number: " . $row['StudentNumber'] . "<br>";
                            echo "Department: " . $row['dept'] . "<br>";


                            // Add other fields as needed
                        }
                    } else {
                        echo "No similar usernames found.";
                    }
                    $user_stmt->close();
                } else {
                    error_log("User Execute failed: (" . $user_stmt->errno . ") " . $user_stmt->error);
                    echo "Error executing user query: " . $user_stmt->error;
                }
            } else {
                echo "No complaints found with the provided ID.";
            }
            $stmt->close();
        } else {
            error_log("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
            echo "Error executing query: " . $stmt->error;
        }
    } else {
        error_log("Prepare failed: (" . $conn->errno . ") " . $conn->error);
        echo "Error preparing query: " . $conn->error;
    }
} else {
    echo "Complaint ID not set in POST request.";
    error_log("Complaint ID not set in POST request.");
}

$conn->close();
?>
