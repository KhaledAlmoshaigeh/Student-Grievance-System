<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

// Check if the username is set in the session
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
} else {
    // Redirect if the username is not set
    header("Location: login.php");
    exit();
}

require 'connection.php'; // Include your database connection script

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch data from the 'complaints' table
$sql = "SELECT * FROM $complaint WHERE username = '$username'";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>review</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="navs.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-custom navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="home.php"><h1 class="navtitle">Student Grievance System</h1></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="student.php">Create complaint</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="studentreview.php">Review status</a>
              </li>
             

            </ul>
            <a href="login.php"><button type="button" class="btn btn-outline-info login">Log out</button></a>
        </div>
    </div>
</nav>
<br>
<h2><center>Welcome, <?php echo $username; ?></center></h2>
<table class="table">
<thead>
<tr>
    <th>Complaint ID</th>
    <th>Title</th>
    <th>Department</th>
    <th>Status</th>
    <th>Date</th>

</tr>
</thead>
<tbody>
<?php
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['number'] . "</td>";
    echo "<td>" . $row['title'] . "</td>";
    echo "<td>" . $row['dept'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>" . $row['time'] . "</td>";
}
?>
</tbody>
</table>
    
</body>
</html>