<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

// Check if the username is set in the session
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
} else {
    // Redirect if the username is not set
    header("Location: login.php");
    exit();
}

require 'connection.php'; // Include your database connection script

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch data from the 'complaints' table
$sql = "SELECT * FROM $complaint";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Grievance System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="navs.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-custom navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="home.php"><h1 class="navtitle">Student Grievance System</h1></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="Sgs.php">Manage complaint</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="contact.php">Direct contact</a>
              </li>

            </ul>

            <a href="login.php"><button type="button" class="btn btn-outline-info login">Log out</button></a>
        </div>
    </div>
</nav>
<br>
<h2><center>Welcome, <?php echo $username; ?></center></h2>
<table class="table">
<thead>
<tr>
    <th>Complaint ID</th>
    <th>Title</th>
    <th>Email</th>
    <th>Username</th>
    <th>Complaint</th>
    <th>Department</th>
    <th>Status</th>
    <th>Date</th>
    <th>Update</th>
    <th>Get Student Info</th>
</tr>
</thead>
<tbody>
<?php
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['number'] . "</td>";
    echo "<td>" . $row['title'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . $row['message'] . "</td>";
    echo "<td>" . $row['dept'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td>" . $row['time'] . "</td>";
    echo "<td><button type='button' class='btn btn-outline-primary update-btn' data-bs-toggle='modal' data-bs-target='#updateModal' data-id='" . $row['number'] . "'><b>Update</b></button></td>";
    echo "<td><button type='button' class='btn btn-outline-primary getinfo-btn' data-bs-toggle='modal' data-bs-target='#getinfoModal' data-id='" . $row['number'] . "'><b>Get Student Info</b></button></td>";
    echo "</tr>";
}
?>
</tbody>
</table>

<!-- Update Complaint Modal -->
<div class="modal fade" id="updateModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Update Complaint</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="updateForm">
                    <!-- Email will be set dynamically -->
                    <div class="form-group mb-2">
                        <label>Email:</label>
                        <input type="text" class="form-control" id="email" readonly>
                    </div>
                    <div class="form-group mb-2">
                        <label for="statusSelect">Status:</label>
                        <select class="form-control" id="statusSelect">
                            <option>Reject</option>
                            <option>In-process</option>
                            <option>Fixed</option>
                            <option>Not fixed</option>
                        </select>
                    </div>
                    <div class="form-group mb-2">
                        <label for="deptSelect">Department (optional):</label>
                        <select class="form-control" id="deptSelect">
                            <option value="None" selected>None</option>
                            <option value="HR">HR</option>
                            <option value="Tech">Tech</option>
                            <option value="Finance">Finance</option>
                            <option value="Marketing">Marketing</option>
                        </select>
                    </div>
                    <input type="hidden" id="complaintId" />
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="submitUpdate()">Save changes</button>
            </div>
        </div>
    </div>
</div>

<!-- Get Info Modal -->
<div class="modal fade" id="getinfoModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Student Info</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p id="studentInfo"></p>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.update-btn').on('click', function() {
        const complaintId = $(this).data('id');
        $('#complaintId').val(complaintId);

        // Fetch the email and current details
        $.ajax({
            type: 'POST',
            url: 'sgs-be.php',
            data: { complaintId: complaintId, action: 'fetch' },
            success: function(data) {
                const result = JSON.parse(data);
                $('#email').val(result.email);
                $('#statusSelect').val(result.status);
                $('#deptSelect').val(result.dept);
            }
        });
    });

    $('.getinfo-btn').on('click', function() {
        const complaintId = $(this).data('id');
        console.log("Fetching info for complaint ID:", complaintId); // Debug log

        $.ajax({
            type: 'POST',
            url: 'sgs-be-getinfo.php',
            data: { complaint_id: complaintId },
            success: function(data) {
                console.log("Response from server:", data); // Debug log
                $('#studentInfo').html(data);
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", status, error);
                $('#studentInfo').html('An error occurred while fetching student info.');
            }
        });
    });
});

function submitUpdate() {
    const complaintId = $('#complaintId').val();
    const status = $('#statusSelect').val();
    const dept = $('#deptSelect').val();
    const email = $('#email').val();

    $.ajax({
        type: 'POST',
        url: 'sgs-be.php',
        data: {
            complaintId: complaintId,
            status: status,
            dept: dept,
            email: email,
            action: 'update'
        },
        success: function(response) {
            alert(response);
            location.reload(); // or handle UI update manually
        }
    });
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
