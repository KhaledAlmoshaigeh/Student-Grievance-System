<?php
session_start();
include "connection.php";

if (isset($_POST['username']) && isset($_POST['Password'])) {

    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    $username = validate($_POST['username']);
    $password = validate($_POST['Password']);

    if (empty($username)) {
        echo "Username is required";
        exit();
    }

    if (empty($password)) {
        echo "Password is required";
        exit();
    }

    $query = "SELECT * FROM $account WHERE username='$username' AND Password='$password'";
    $execute = mysqli_query($conn, $query);

    if (mysqli_num_rows($execute) === 1) {
        $row = mysqli_fetch_assoc($execute);

        // Check the user's role
        $role = $row['role'];
        if ($role === 'Student') {
            $_SESSION['username'] = $row['username'];
            header("Location: student.php");
            exit();
        } else {
            $_SESSION['username'] = $row['username'];
            header("Location: sgs.php");
            exit();
        }
    } else {
        echo "User not found";
        exit();
    }
}
?>