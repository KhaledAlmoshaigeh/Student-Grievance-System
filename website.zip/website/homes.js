
  setTimeout(function() {
    document.getElementById("myDiv").classList.add("show");
  }, 700);

  setTimeout(function() {
    document.getElementById("myDiv1").classList.add("show");
  }, 1000);
  setTimeout(function() {
    document.getElementById("myDivm").classList.add("show");
  }, 500);