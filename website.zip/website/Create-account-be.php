<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'connection.php';

$username = $_POST["Username"];
$studentNumber = $_POST["studentNumber"];
$email = $_POST["Email"];
$password = $_POST["password"];
$dept = $_POST["dept"];

$queryinsert = "INSERT INTO $account (username, StudentNumber, Email, dept , Password) VALUES (?, ?, ?, ? ,?)";
$stmt = $conn->prepare($queryinsert);
$stmt->bind_param("sisss", $username, $studentNumber, $email, $dept , $password);
if ($stmt->execute()){
    $mail = new PHPMailer(true);
    try{
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = $sgsEmail;
        ;
        $mail->Password   = $emailPassword;
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom($sgsEmail, 'Student Grievance System');
        $mail->addAddress($email, $username);

        $mail->isHTML(true);
        $mail->Subject = 'Welcome to Our Service!';
        $mail->Body    = "Thank you, <b>$username</b>, for registering with us.";
        $mail->send();} 
        catch (Exception $e) {
            echo $e;
        }
    }

$stmt->close();
$conn->close();

echo "DONE";
?>
