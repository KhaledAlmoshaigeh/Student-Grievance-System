<?php
include 'connection.php'; // Include your database connection script

// Fetch images from the database
$sql = $conn->query("SELECT image FROM complaint");
while ($row = $sql->fetch_assoc()) {
    $imageData = $row['image'];
    $encodedImageData = base64_encode($imageData);
    
    // Display the image
    echo '<img src="data:image/jpeg;base64,' . $encodedImageData . '" />';
}
?>